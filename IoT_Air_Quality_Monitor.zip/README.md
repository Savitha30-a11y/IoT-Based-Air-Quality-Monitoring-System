# 🌍 IoT-Based Air Quality Monitoring System

A cloud-connected system using ESP32 that continuously measures and displays air quality parameters such as AQI, CO₂, temperature, and humidity on both an LCD and the Blynk IoT dashboard.

## 👩‍💻 Author
**Savitha**

## ⚙️ Features
- Monitors Air Quality Index (AQI), CO₂, Temperature, and Humidity.
- Displays live readings on a 16x2 I²C LCD.
- Sends data to the Blynk Cloud for remote monitoring.
- Works on Wokwi simulation and real ESP32 hardware.

## 🧩 Components
- ESP32 Dev Module
- I²C 16x2 LCD Display
- Wi-Fi (Wokwi-GUEST for simulation)

## 🔌 Connections
| LCD Pin | ESP32 Pin | Description |
|----------|------------|-------------|
| GND | GND | Ground |
| VCC | 5V | Power |
| SDA | GPIO 21 | I²C Data |
| SCL | GPIO 22 | I²C Clock |

## 🚀 Simulation Steps (Wokwi)
1. Go to [https://wokwi.com/projects/new/esp32](https://wokwi.com/projects/new/esp32)
2. Add an **LCD 16x2 (I2C)** component.
3. Connect the pins as shown above.
4. Paste the code from `IoT_Air_Quality_Monitor.ino`.
5. Replace Blynk credentials.
6. Start the simulation and check the LCD and Serial Monitor.

## 📊 Blynk Dashboard Setup
| Widget | Virtual Pin | Purpose |
|---------|--------------|----------|
| Gauge / Label | V1 | AQI |
| Gauge / Label | V2 | CO₂ (ppm) |
| Gauge / Label | V3 | Temperature (°C) |
| Gauge / Label | V4 | Humidity (%) |
| SuperChart | V1–V4 | Live Trends |

---
🛠 Developed by Savitha for the **CODTECH Internship Project**.
